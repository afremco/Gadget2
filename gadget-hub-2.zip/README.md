# ⚡ Gadget Hub

A full custom e-commerce storefront for Zambia — built with a Node.js/Express backend and a vanilla HTML/CSS/JS frontend. It accepts **Zambian mobile money (MTN, Airtel, Zamtel) via MoneyUnify** and **international payments via PayPal**.

No WordPress, no Shopify — this is your own code that you fully control.

---

## What's inside

```
gadgethub/
├── server/
│   ├── index.js        # Express server + payment endpoints
│   └── catalog.js      # Products + trusted server-side prices
├── public/
│   └── index.html      # The storefront (frontend)
├── .env.example        # Copy to .env and add your keys
├── package.json
└── README.md
```

---

## 1. Run it locally (5 minutes)

You need **Node.js 18+** installed.

```bash
# 1. Install dependencies
npm install

# 2. Create your environment file
cp .env.example .env
#    then open .env and paste in your keys (see below)

# 3. Start the server
npm start
```

Open **http://localhost:4000** — the store is live locally. You can browse, add to cart, and check out. Payments stay in **test mode** until you add live keys.

---

## 2. Getting your payment keys

### MoneyUnify (Zambian mobile money) — required for Zambia
1. Sign up at **https://moneyunify.one**
2. Open your **Businesses Dashboard** and copy your **auth_id**
3. Paste it into `.env` as `MU_AUTH_ID`
4. Keep `MU_SANDBOX=true` while testing; set it to `false` to take real money.

How it works: when a customer checks out, MoneyUnify sends a **USSD PIN prompt to their phone**. They approve with their MTN/Airtel/Zamtel PIN, and your server confirms the payment. No card details ever touch your site.

### PayPal (international) — optional
1. Sign up at **https://developer.paypal.com**
2. Create an app under **Apps & Credentials**
3. Copy the **Client ID** and **Secret** into `.env`
4. Keep `PAYPAL_MODE=sandbox` for testing; switch to `live` to go live.

> 🔒 Your secret keys live only in `.env` on the server. They are never sent to the browser, and `.gitignore` keeps `.env` out of GitHub.

---

## 3. Going LIVE for free

You can host this whole app at zero cost on a free Node hosting tier:

### Option A — Render (recommended, free tier)
1. Push this folder to a **GitHub** repo.
2. Go to **https://render.com** → New → Web Service → connect your repo.
3. Settings:
   - **Build command:** `npm install`
   - **Start command:** `npm start`
4. Add your `.env` keys under **Environment** in the Render dashboard.
5. Deploy. Render gives you a free `https://gadgethub.onrender.com` URL with free SSL.

### Option B — Railway / Cyclic / Fly.io
Same idea — connect the GitHub repo, set environment variables, deploy.

### Free custom domain — gadgethub.shop
Your domain is **gadgethub.shop**. To connect it after deploying to Render:
1. In the Render dashboard, open your service → **Settings → Custom Domains** → add `gadgethub.shop` and `www.gadgethub.shop`.
2. Render shows you a DNS target (a CNAME / A record).
3. Log in to wherever you registered gadgethub.shop → **DNS settings** → add the record Render gave you.
4. Wait for DNS to propagate (minutes to a few hours). Render issues a free SSL certificate automatically.
5. Make sure `BASE_URL=https://gadgethub.shop` is set in your environment variables.

Your store will then be live at **https://gadgethub.shop** with HTTPS.

---

## 4. How payments stay secure

- **Prices live on the server** (`catalog.js`). Even though the browser shows prices, the server **recomputes every total** before charging — so a buyer can't edit a price in their browser and pay less.
- **MoneyUnify payments are confirmed server-side** by polling the verify endpoint until the customer approves on their phone.
- **PayPal orders are created and captured server-side**, never trusting the browser for the amount.

---

## 5. Next steps to make it production-grade

- Connect a database (e.g. free Postgres on Render/Supabase) to store orders.
- Send confirmation emails (Resend, SendGrid free tier).
- Add a live FX rate for the ZMW→USD PayPal conversion (currently a fixed rate in `server/index.js`).
- Add an admin page to manage products and view orders.

---

Built for Gadget Hub Zambia. 🇿🇲
