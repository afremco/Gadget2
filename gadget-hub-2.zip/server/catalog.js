// ============================================================
//  Gadget Hub — Product Catalog (server-side source of truth)
//  Prices are defined HERE on the server so a buyer cannot
//  tamper with prices from the browser. The frontend reads
//  these via /api/products.
// ============================================================

export const products = [
  {
    id: "phone-galaxy-s24",
    name: "Samsung Galaxy S24 Ultra",
    category: "Smartphones",
    priceZMW: 38999,
    image: "📱",
    badge: "Best Seller",
    blurb: "6.8\" Dynamic AMOLED, 200MP camera, Snapdragon 8 Gen 3, S Pen.",
    stock: 12,
  },
  {
    id: "phone-iphone-15",
    name: "iPhone 15 Pro",
    category: "Smartphones",
    priceZMW: 41500,
    image: "📱",
    badge: "New",
    blurb: "A17 Pro chip, titanium frame, 48MP main camera, USB-C.",
    stock: 8,
  },
  {
    id: "laptop-macbook-air",
    name: "MacBook Air M3 13\"",
    category: "Laptops",
    priceZMW: 52000,
    image: "💻",
    badge: null,
    blurb: "Apple M3, 16GB RAM, 512GB SSD, 18-hour battery life.",
    stock: 5,
  },
  {
    id: "laptop-dell-xps",
    name: "Dell XPS 13 Plus",
    category: "Laptops",
    priceZMW: 47800,
    image: "💻",
    badge: null,
    blurb: "Intel Core Ultra 7, 16GB RAM, 1TB SSD, 3.5K OLED touch.",
    stock: 4,
  },
  {
    id: "audio-airpods-pro",
    name: "AirPods Pro (2nd Gen)",
    category: "Audio",
    priceZMW: 6200,
    image: "🎧",
    badge: "Deal",
    blurb: "Active noise cancellation, adaptive audio, USB-C charging case.",
    stock: 25,
  },
  {
    id: "audio-sony-xm5",
    name: "Sony WH-1000XM5",
    category: "Audio",
    priceZMW: 9400,
    image: "🎧",
    badge: null,
    blurb: "Industry-leading noise cancellation, 30-hour battery, crystal calls.",
    stock: 15,
  },
  {
    id: "wear-watch-ultra",
    name: "Apple Watch Ultra 2",
    category: "Wearables",
    priceZMW: 21500,
    image: "⌚",
    badge: null,
    blurb: "Titanium case, 36-hour battery, precision dual-frequency GPS.",
    stock: 9,
  },
  {
    id: "wear-galaxy-watch",
    name: "Galaxy Watch 6 Classic",
    category: "Wearables",
    priceZMW: 8900,
    image: "⌚",
    badge: "Deal",
    blurb: "Rotating bezel, advanced sleep coaching, body composition.",
    stock: 18,
  },
  {
    id: "game-ps5",
    name: "PlayStation 5 Slim",
    category: "Gaming",
    priceZMW: 16500,
    image: "🎮",
    badge: "Hot",
    blurb: "Ultra-high-speed SSD, 4K gaming, DualSense haptic controller.",
    stock: 6,
  },
  {
    id: "acc-powerbank",
    name: "Anker 737 Power Bank 24,000mAh",
    category: "Accessories",
    priceZMW: 2400,
    image: "🔋",
    badge: null,
    blurb: "140W output, charges a laptop, smart digital display.",
    stock: 40,
  },
  {
    id: "acc-charger",
    name: "Anker 65W GaN Charger",
    category: "Accessories",
    priceZMW: 1100,
    image: "🔌",
    badge: null,
    blurb: "Compact 3-port fast charger for phone, tablet and laptop.",
    stock: 50,
  },
  {
    id: "home-echo-dot",
    name: "Amazon Echo Dot (5th Gen)",
    category: "Smart Home",
    priceZMW: 1850,
    image: "🏠",
    badge: null,
    blurb: "Smart speaker with Alexa, richer sound, temperature sensor.",
    stock: 30,
  },
];

// Helper: look up a product by id (used to verify cart prices server-side).
export function findProduct(id) {
  return products.find((p) => p.id === id) || null;
}

// Helper: given a cart [{id, qty}], compute the trusted total in ZMW.
export function computeCartTotal(cart) {
  if (!Array.isArray(cart)) return { items: [], totalZMW: 0 };
  const items = [];
  let totalZMW = 0;
  for (const line of cart) {
    const product = findProduct(line.id);
    const qty = Math.max(1, Math.min(99, parseInt(line.qty, 10) || 1));
    if (!product) continue;
    const lineTotal = product.priceZMW * qty;
    totalZMW += lineTotal;
    items.push({
      id: product.id,
      name: product.name,
      priceZMW: product.priceZMW,
      qty,
      lineTotalZMW: lineTotal,
    });
  }
  return { items, totalZMW };
}
