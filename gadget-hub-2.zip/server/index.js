// ============================================================
//  Gadget Hub — Backend Server
//  - Serves the storefront (public/)
//  - Exposes a product API
//  - Initializes & verifies MoneyUnify mobile money payments (MTN/Airtel/Zamtel)
//  - Creates & captures PayPal orders (international)
//
//  SECURITY NOTE: All secret keys live in .env on the server and
//  are NEVER sent to the browser. Cart totals are recomputed
//  server-side so a buyer cannot change a price in the browser.
// ============================================================

import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import axios from "axios";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import checkoutSdk from "@paypal/checkout-server-sdk";

import { products, computeCartTotal } from "./catalog.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 4000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const BASE_CURRENCY = process.env.BASE_CURRENCY || "ZMW";

// ---------- Middleware ----------
app.use(
  helmet({
    contentSecurityPolicy: false, // relaxed so the inline storefront + payment scripts load
  })
);
// Only allow the live storefront domain (and localhost during development).
const allowedOrigins = [
  "https://gadgethub.shop",
  "https://www.gadgethub.shop",
  "http://localhost:4000",
];
app.use(
  cors({
    origin: (origin, cb) => {
      // allow same-origin / server-to-server requests (no origin) and whitelisted domains
      if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
      return cb(new Error("Not allowed by CORS"));
    },
  })
);
// Capture the raw body for webhook signature checks, plus normal JSON parsing.
app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  })
);
app.use(express.static(path.join(__dirname, "..", "public")));

// Basic rate limiting on the API to deter abuse.
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use("/api/", apiLimiter);

// ---------- PayPal client ----------
function paypalClient() {
  const id = process.env.PAYPAL_CLIENT_ID;
  const secret = process.env.PAYPAL_CLIENT_SECRET;
  const Environment =
    process.env.PAYPAL_MODE === "live"
      ? checkoutSdk.core.LiveEnvironment
      : checkoutSdk.core.SandboxEnvironment;
  return new checkoutSdk.core.PayPalHttpClient(new Environment(id, secret));
}

// A simple static USD rate for PayPal display. In production, pull a live
// FX rate from an API and cache it. ZMW is not a PayPal settlement currency,
// so international buyers are charged in USD.
const ZMW_TO_USD = 1 / 26; // ~26 ZMW per USD (adjust / fetch live as needed)

// ============================================================
//  PRODUCT API
// ============================================================
app.get("/api/products", (_req, res) => {
  res.json({ currency: BASE_CURRENCY, products });
});

app.get("/api/config", (_req, res) => {
  // No secret keys are exposed to the browser. MoneyUnify is server-to-server,
  // so the frontend only needs to know which payment methods are available.
  res.json({
    moneyUnifyEnabled: Boolean(process.env.MU_AUTH_ID),
    paypalClientId: process.env.PAYPAL_CLIENT_ID || "",
    paypalMode: process.env.PAYPAL_MODE || "sandbox",
    baseCurrency: BASE_CURRENCY,
    zmwToUsd: ZMW_TO_USD,
  });
});

// Recompute a cart total on the server (trusted source of truth).
app.post("/api/quote", (req, res) => {
  const { cart } = req.body || {};
  const quote = computeCartTotal(cart);
  res.json(quote);
});

// ============================================================
//  MONEYUNIFY  (Zambian Mobile Money: MTN, Airtel, Zamtel)
//  Flow (server-to-server, no browser SDK):
//   1) Browser POSTs cart + phone -> /api/momo/request
//      We compute the trusted total and ask MoneyUnify to push
//      a USSD PIN prompt to the customer's phone.
//   2) Customer enters their mobile money PIN on their phone.
//   3) Browser polls /api/momo/verify with the transaction_id
//      until MoneyUnify reports the payment as successful.
// ============================================================
const MU_BASE = "https://api.moneyunify.one";

// Turn "097..." or "26097..." into the international format MoneyUnify expects.
function normalizeZmPhone(raw) {
  let p = String(raw || "").replace(/[^\d]/g, "");
  if (p.startsWith("260")) return p;
  if (p.startsWith("0")) return "260" + p.slice(1);
  if (p.length === 9) return "260" + p; // e.g. 97xxxxxxx
  return p;
}

app.post("/api/momo/request", async (req, res) => {
  try {
    const { cart, customer } = req.body || {};
    if (!process.env.MU_AUTH_ID) {
      return res.status(500).json({ status: "error", message: "Mobile money is not configured on the server." });
    }
    const phone = normalizeZmPhone(customer?.phone);
    if (!/^260\d{9}$/.test(phone)) {
      return res.status(400).json({ status: "error", message: "Enter a valid Zambian mobile money number." });
    }
    const { items, totalZMW } = computeCartTotal(cart);
    if (!items.length || totalZMW <= 0) {
      return res.status(400).json({ status: "error", message: "Your cart is empty." });
    }

    const body = new URLSearchParams({
      auth_id: process.env.MU_AUTH_ID,
      amount: String(totalZMW),
      from_payer: phone,
      narration: "Gadget Hub order",
    });

    const resp = await axios.post(`${MU_BASE}/payments/request`, body, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });

    const data = resp.data || {};
    if (data.isError) {
      return res.status(400).json({ status: "error", message: data.message || "Could not start payment." });
    }
    // Return the transaction id so the browser can poll for confirmation.
    const transactionId = data?.data?.transaction_id || data?.transaction_id;
    return res.json({
      status: "pending",
      message: "Check your phone and enter your mobile money PIN to approve.",
      transactionId,
      expectedAmount: totalZMW,
    });
  } catch (err) {
    console.error("MoneyUnify request error:", err?.response?.data || err.message);
    return res.status(500).json({ status: "error", message: "Could not start the mobile money payment." });
  }
});

app.post("/api/momo/verify", async (req, res) => {
  try {
    const { transactionId, expectedAmount } = req.body || {};
    if (!transactionId) {
      return res.status(400).json({ status: "error", message: "Missing transaction id." });
    }
    const body = new URLSearchParams({
      auth_id: process.env.MU_AUTH_ID,
      transaction_id: transactionId,
    });
    const resp = await axios.post(`${MU_BASE}/payments/verify`, body, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });

    const data = resp.data?.data || {};
    const paidStatus = String(data.status || "").toLowerCase();

    if (paidStatus === "successful" && Number(data.amount) >= Number(expectedAmount)) {
      // TODO: mark order paid in your database, email the customer, arrange delivery.
      return res.json({ status: "success", message: "Payment confirmed.", data });
    }
    if (paidStatus === "failed" || paidStatus === "cancelled") {
      return res.json({ status: "failed", message: "Payment was not completed." });
    }
    // Still waiting for the customer to enter their PIN.
    return res.json({ status: "pending", message: "Waiting for approval on your phone." });
  } catch (err) {
    console.error("MoneyUnify verify error:", err?.response?.data || err.message);
    return res.status(500).json({ status: "error", message: "Could not verify the payment." });
  }
});

// ============================================================
//  PAYPAL  (International)
// ============================================================
app.post("/api/paypal/create-order", async (req, res) => {
  try {
    const { cart } = req.body || {};
    const { items, totalZMW } = computeCartTotal(cart);
    if (!items.length || totalZMW <= 0) {
      return res.status(400).json({ error: "Your cart is empty." });
    }
    const totalUSD = (totalZMW * ZMW_TO_USD).toFixed(2);

    const request = new checkoutSdk.orders.OrdersCreateRequest();
    request.prefer("return=representation");
    request.requestBody({
      intent: "CAPTURE",
      purchase_units: [
        {
          amount: { currency_code: "USD", value: totalUSD },
          description: "Gadget Hub order",
        },
      ],
    });
    const order = await paypalClient().execute(request);
    res.json({ id: order.result.id, totalUSD });
  } catch (err) {
    console.error("PayPal create error:", err.message);
    res.status(500).json({ error: "Could not create PayPal order." });
  }
});

app.post("/api/paypal/capture-order", async (req, res) => {
  try {
    const { orderId } = req.body || {};
    if (!orderId) return res.status(400).json({ error: "Missing order id." });
    const request = new checkoutSdk.orders.OrdersCaptureRequest(orderId);
    request.requestBody({});
    const capture = await paypalClient().execute(request);
    const status = capture.result.status;
    if (status === "COMPLETED") {
      // TODO: mark order paid, fulfil, email the customer.
      return res.json({ status: "success", details: capture.result });
    }
    res.status(400).json({ status: "failed", details: capture.result });
  } catch (err) {
    console.error("PayPal capture error:", err.message);
    res.status(500).json({ error: "Could not capture PayPal payment." });
  }
});

// ---------- Fallback: serve the storefront for any unknown route ----------
app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`\n🛒  Gadget Hub running at ${BASE_URL}`);
  console.log(`    Currency: ${BASE_CURRENCY} | PayPal: ${process.env.PAYPAL_MODE || "sandbox"}\n`);
});
